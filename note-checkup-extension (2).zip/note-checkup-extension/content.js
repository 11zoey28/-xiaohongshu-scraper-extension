// content.js
// 通过 popup.js 在点击插件图标时"现场注入"到当前页面,不再依赖页面加载时自动注入,
// 这样即使页面是在装插件之前就打开的,也能正常读取。
// 只读取当前页面上已经显示的内容,不做任何自动抓取或批量请求。

if (!window.__noteCheckupInjected) {
  window.__noteCheckupInjected = true;

  const NUM_PATTERN = /^\d{1,3}(,\d{3})*(\.\d+)?[万wWkK]?$/;

  function guessTitle() {
    const og = document.querySelector('meta[property="og:title"]');
    if (og && og.content) return og.content.trim();
    const h1 = document.querySelector('h1');
    if (h1 && h1.textContent.trim()) return h1.textContent.trim();
    return document.title || '';
  }

  function parseNum(text) {
    let t = String(text).replace(/,/g, '').trim();
    const wan = /[万w]$/i.test(t);
    const k = /k$/i.test(t) && !wan;
    t = t.replace(/[万wWkK]/g, '');
    let n = parseFloat(t);
    if (isNaN(n)) return null;
    if (wan) n *= 10000;
    if (k) n *= 1000;
    return Math.round(n);
  }

  function findNumberNear(el) {
    if (!el) return null;
    const own = el.textContent.trim();
    if (NUM_PATTERN.test(own)) return parseNum(own);
    const candidates = el.querySelectorAll('*');
    for (const c of candidates) {
      const t = c.textContent.trim();
      if (NUM_PATTERN.test(t)) return parseNum(t);
    }
    if (el.parentElement) {
      for (const sib of el.parentElement.querySelectorAll('*')) {
        const t = sib.textContent.trim();
        if (NUM_PATTERN.test(t)) return parseNum(t);
      }
    }
    return null;
  }

  function findByKeywords(keywords) {
    const all = document.querySelectorAll('[aria-label], [title], button, span, div');
    for (const el of all) {
      const label = (el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase();
      if (!label) continue;
      if (keywords.some(k => label.includes(k))) {
        const n = findNumberNear(el);
        if (n !== null) return n;
      }
    }
    return null;
  }

  // 兜底:找互动栏区域里成组出现的数字(通常在页面底部或右侧,几个数字挨在一起)
  function findInteractionCluster() {
    const nodesWithNums = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, null);
    let node;
    while ((node = walker.nextNode())) {
      if (node.children.length > 0) continue; // 只看叶子节点
      const t = node.textContent.trim();
      if (NUM_PATTERN.test(t)) {
        const rect = node.getBoundingClientRect();
        if (rect.width === 0 && rect.height === 0) continue;
        nodesWithNums.push({ el: node, value: parseNum(t), top: rect.top, left: rect.left });
      }
    }
    // 找纵坐标接近的一组(同一行的互动栏),取数量最多的一簇
    const clusters = [];
    nodesWithNums.forEach(n => {
      let cluster = clusters.find(c => Math.abs(c.top - n.top) < 12);
      if (!cluster) { cluster = { top: n.top, items: [] }; clusters.push(cluster); }
      cluster.items.push(n);
    });
    clusters.sort((a, b) => b.items.length - a.items.length);
    if (clusters.length && clusters[0].items.length >= 2) {
      return clusters[0].items.sort((a, b) => a.left - b.left).map(i => i.value);
    }
    return [];
  }

  function collectNumberCandidates() {
    const seen = new Set();
    const results = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    let node;
    while ((node = walker.nextNode())) {
      const text = node.textContent.trim();
      if (!text || text.length > 8) continue;
      if (!NUM_PATTERN.test(text)) continue;
      const key = text + '|' + results.length;
      if (seen.has(key)) continue;
      seen.add(key);
      const parent = node.parentElement;
      const context = parent ? (parent.getAttribute('aria-label') || parent.className || '') : '';
      results.push({ value: text, context: String(context).slice(0, 40) });
      if (results.length >= 20) break;
    }
    return results;
  }

  function extract() {
    let likes = findByKeywords(['赞', 'like']);
    let comments = findByKeywords(['评论', 'comment']);
    let saves = findByKeywords(['收藏', 'favorite', 'collect']);
    const views = findByKeywords(['曝光', '浏览', 'view', 'impression']);

    let confident = likes !== null && comments !== null;

    // 关键词都没找到时,试试"互动栏成簇数字"这个兜底猜测
    if (!confident) {
      const cluster = findInteractionCluster();
      if (cluster.length >= 3) {
        // 小红书网页版常见顺序:赞、收藏、评论
        if (likes === null) likes = cluster[0];
        if (saves === null) saves = cluster[1];
        if (comments === null) comments = cluster[2];
      }
    }

    return {
      title: guessTitle(),
      url: location.href,
      hour: new Date().getHours(),
      likes, comments, saves, views,
      confident,
      candidates: collectNumberCandidates()
    };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'EXTRACT_PAGE_DATA') {
      sendResponse(extract());
    }
    return true;
  });
}
