let posts = [];

const $ = id => document.getElementById(id);
function fmtPct(n){ return (n*100).toFixed(2) + '%'; }
function escapeHtml(s){ const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

function withComputed(p){
  return {
    ...p,
    rate: p.views > 0 ? (p.likes + p.comments + p.saves) / p.views : 0,
    len: [...p.title].length
  };
}

function load(){
  chrome.storage.local.get({ posts: [] }, (data) => {
    posts = data.posts.map(withComputed);
    render();
  });
}

function save(){
  chrome.storage.local.set({ posts: posts.map(({rate, len, ...rest}) => rest) });
}

function removePost(id){
  posts = posts.filter(p => p.id !== id);
  save();
  render();
}

function render(){
  $('count').textContent = posts.length;
  const list = $('posts-list');
  const empty = $('empty-msg');
  list.innerHTML = '';

  if(posts.length === 0){
    empty.style.display = 'block';
    $('chart-card').style.display = 'none';
    $('analysis').style.display = 'none';
    return;
  }
  empty.style.display = 'none';

  posts.forEach(p => {
    const item = document.createElement('div');
    item.className = 'post-item';

    const info = document.createElement('div');
    info.style.flex = '1';
    info.style.minWidth = '0';
    const t = document.createElement('div');
    t.className = 'title';
    t.textContent = p.title;
    const m = document.createElement('div');
    m.className = 'meta';
    m.textContent = `${p.likes}赞 · ${p.comments}评论 · ${p.saves}收藏 · 曝光${p.views}${p.hour !== null && p.hour !== undefined ? ' · ' + p.hour + '点' : ''}${p.emoji ? ' · 带emoji' : ''}`;
    info.appendChild(t); info.appendChild(m);

    const rate = document.createElement('div');
    rate.className = 'rate';
    rate.textContent = p.views > 0 ? fmtPct(p.rate) : '无曝光数据';

    const del = document.createElement('button');
    del.textContent = '✕';
    del.addEventListener('click', () => removePost(p.id));

    item.appendChild(info); item.appendChild(rate); item.appendChild(del);
    list.appendChild(item);
  });

  const withViews = posts.filter(p => p.views > 0);
  if(withViews.length > 0){
    $('chart-card').style.display = 'block';
    renderBars(withViews);
  } else {
    $('chart-card').style.display = 'none';
  }

  if(withViews.length >= 2){
    $('analysis').style.display = 'grid';
    renderScatter(withViews);
    renderEmojiBars(withViews);
  } else {
    $('analysis').style.display = 'none';
  }
}

function renderBars(list){
  const max = Math.max(...list.map(p => p.rate), 0.0001);
  const avg = list.reduce((a,p) => a + p.rate, 0) / list.length;
  const avgPct = (avg / max) * 100;

  const container = $('bars');
  container.innerHTML = '';
  list.forEach(p => {
    const pct = (p.rate / max) * 100;
    const row = document.createElement('div');
    row.className = 'bar-row';
    row.innerHTML = `
      <div class="bar-label" title="${escapeHtml(p.title)}">${escapeHtml(p.title)}</div>
      <div class="bar-track">
        <div class="bar-fill" style="width:${pct}%"></div>
        <div class="avg-line" style="left:${avgPct}%"></div>
      </div>
      <div class="bar-val">${fmtPct(p.rate)}</div>
    `;
    container.appendChild(row);
  });
}

function pearson(xs, ys){
  const n = xs.length;
  const mx = xs.reduce((a,b)=>a+b,0)/n;
  const my = ys.reduce((a,b)=>a+b,0)/n;
  let num=0, dx2=0, dy2=0;
  for(let i=0;i<n;i++){
    const dx = xs[i]-mx, dy = ys[i]-my;
    num += dx*dy; dx2 += dx*dx; dy2 += dy*dy;
  }
  if(dx2===0 || dy2===0) return 0;
  return num / Math.sqrt(dx2*dy2);
}

function renderScatter(list){
  const w = 400, h = 220, pad = 34;
  const lens = list.map(p=>p.len);
  const rates = list.map(p=>p.rate);
  const maxLen = Math.max(...lens, 1);
  const maxRate = Math.max(...rates, 0.0001);

  let dots = '';
  list.forEach(p => {
    const x = pad + (p.len / maxLen) * (w - pad*2);
    const y = h - pad - (p.rate / maxRate) * (h - pad*2);
    dots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5" fill="${p.emoji ? '#7CE0C6' : '#FF5A5F'}" opacity="0.9"><title>${escapeHtml(p.title)}</title></circle>`;
  });

  $('scatter').innerHTML = `
    <svg class="scatter-svg" viewBox="0 0 ${w} ${h}">
      <line x1="${pad}" y1="${h-pad}" x2="${w-10}" y2="${h-pad}" stroke="#33353F" stroke-width="1"/>
      <line x1="${pad}" y1="10" x2="${pad}" y2="${h-pad}" stroke="#33353F" stroke-width="1"/>
      <text x="${w/2}" y="${h-6}" text-anchor="middle" class="axis-label">标题字数 →</text>
      <text x="12" y="${h/2}" text-anchor="middle" class="axis-label" transform="rotate(-90 12 ${h/2})">互动率 →</text>
      ${dots}
    </svg>
  `;

  const r = pearson(lens, rates);
  let desc;
  if(Math.abs(r) < 0.2) desc = '在这批数据里,标题长度和互动率几乎没什么关系';
  else if(r > 0) desc = `标题越长,互动率似乎<b>越高</b>一点`;
  else desc = `标题越长,互动率似乎<b>越低</b>一点`;
  $('length-insight').innerHTML = `相关系数 r ≈ <b>${r.toFixed(2)}</b>。${desc}(样本 ${list.length} 篇,仅供参考)。`;
}

function renderEmojiBars(list){
  const withEmoji = list.filter(p => p.emoji);
  const withoutEmoji = list.filter(p => !p.emoji);
  const avgWith = withEmoji.length ? withEmoji.reduce((a,p)=>a+p.rate,0)/withEmoji.length : 0;
  const avgWithout = withoutEmoji.length ? withoutEmoji.reduce((a,p)=>a+p.rate,0)/withoutEmoji.length : 0;
  const max = Math.max(avgWith, avgWithout, 0.0001);

  const rows = [
    { label: `带 emoji (${withEmoji.length}篇)`, val: avgWith, cls: 'mint' },
    { label: `不带 emoji (${withoutEmoji.length}篇)`, val: avgWithout, cls: '' }
  ];
  let html = '';
  rows.forEach(r => {
    const pct = (r.val / max) * 100;
    html += `
      <div class="bar-row">
        <div class="bar-label">${r.label}</div>
        <div class="bar-track"><div class="bar-fill ${r.cls}" style="width:${pct}%"></div></div>
        <div class="bar-val">${fmtPct(r.val)}</div>
      </div>
    `;
  });
  $('emoji-bars').innerHTML = html;

  let insight;
  if(withEmoji.length === 0 || withoutEmoji.length === 0){
    insight = '两种标题都要有几篇样本,对比才有意义。';
  } else if(avgWith > avgWithout){
    const diff = ((avgWith/avgWithout - 1) * 100).toFixed(0);
    insight = `带 emoji 的标题平均互动率比不带的<b>高 ${diff}%</b>。`;
  } else if(avgWith < avgWithout){
    const diff = ((avgWithout/avgWith - 1) * 100).toFixed(0);
    insight = `不带 emoji 的标题平均互动率反而<b>高 ${diff}%</b>。`;
  } else {
    insight = '两者打平,emoji 在这批数据里没看出明显作用。';
  }
  $('emoji-insight').innerHTML = insight;
}

$('clear-btn').addEventListener('click', () => {
  if(!confirm('确定清空全部已保存的笔记数据?')) return;
  posts = [];
  save();
  render();
});

load();
