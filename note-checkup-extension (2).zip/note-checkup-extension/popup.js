function $(id){ return document.getElementById(id); }

function parseNum(text){
  let t = String(text).replace(/,/g, '');
  const wan = /[万w]$/i.test(t);
  const k = /k$/i.test(t) && !wan;
  t = t.replace(/[万wWkK]/g, '');
  let n = parseFloat(t);
  if (isNaN(n)) return null;
  if (wan) n *= 10000;
  if (k) n *= 1000;
  return Math.round(n);
}

let lastTargetField = 'likes';

function renderCandidates(candidates){
  const wrap = $('candidates');
  wrap.innerHTML = '';
  if (!candidates || candidates.length === 0) {
    wrap.innerHTML = '<span class="hint">没找到别的数字了。</span>';
    return;
  }
  candidates.forEach(c => {
    const chip = document.createElement('div');
    chip.className = 'chip';
    chip.textContent = c.value;
    chip.title = c.context || '';
    chip.addEventListener('click', () => {
      const n = parseNum(c.value);
      if (n === null) return;
      $(lastTargetField).value = n;
      const order = ['likes','comments','saves','views'];
      const idx = order.indexOf(lastTargetField);
      lastTargetField = order[(idx + 1) % order.length];
    });
    wrap.appendChild(chip);
  });
}

function fillFromResponse(resp, guessedOrder){
  $('title').value = resp.title || '';
  $('hour').value = resp.hour ?? '';

  if (resp.likes !== null) $('likes').value = resp.likes;
  if (resp.comments !== null) $('comments').value = resp.comments;
  if (resp.saves !== null) $('saves').value = resp.saves;
  if (resp.views !== null) $('views').value = resp.views;

  if (resp.confident) {
    $('status').style.color = '#7CE0C6';
    $('status').textContent = '已自动填好,核对一眼没问题就直接保存。';
  } else if (resp.likes !== null || resp.comments !== null || resp.saves !== null) {
    $('status').style.color = '#8A8D98';
    $('status').textContent = '按猜测顺序填的,不一定对 — 请对照屏幕上"点赞/评论/收藏"的实际数字核对一遍。';
  } else {
    $('status').style.color = '#8A8D98';
    $('status').textContent = '没能自动认出数字,下面候选列表里点一下填进对应框。';
  }
  renderCandidates(resp.candidates);
}

async function init(){
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  if (!tab || !tab.id) return;

  const tryExtract = () => new Promise((resolve) => {
    chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_PAGE_DATA' }, (resp) => {
      if (chrome.runtime.lastError) resolve(null);
      else resolve(resp);
    });
  });

  let resp = await tryExtract();

  if (!resp) {
    // 页面上还没有注入过脚本(常见于装插件之前就已经打开的旧标签页),现场注入一次再试
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      resp = await tryExtract();
    } catch (e) {
      // 注入失败,通常是该页面不允许脚本注入(比如浏览器内置页面)
    }
  }

  if (!resp) {
    $('status').style.color = '#8A8D98';
    $('status').textContent = '这个页面读不了(可能不是小红书笔记页,或需要刷新一下再试),手动填写也可以保存。';
    return;
  }

  fillFromResponse(resp);
}

$('save-btn').addEventListener('click', () => {
  const post = {
    id: Date.now(),
    title: $('title').value.trim(),
    likes: Number($('likes').value) || 0,
    comments: Number($('comments').value) || 0,
    saves: Number($('saves').value) || 0,
    views: Number($('views').value) || 0,
    hour: $('hour').value === '' ? null : Number($('hour').value),
    emoji: $('emoji').checked
  };
  if (!post.title) {
    $('status').textContent = '标题不能为空';
    $('status').style.color = '#FF5A5F';
    return;
  }
  chrome.storage.local.get({ posts: [] }, (data) => {
    const posts = data.posts;
    posts.push(post);
    chrome.storage.local.set({ posts }, () => {
      $('status').style.color = '#7CE0C6';
      $('status').textContent = '已保存,可以点下面打开体检室查看分析。';
    });
  });
});

$('open-btn').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('analysis.html') });
});

init();
